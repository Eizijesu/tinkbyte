import { createClient } from "tinacms/dist/client";
import { queries } from "./types";
export const client = createClient({ url: 'http://localhost:4001/graphql', token: '10715f4f2d949593f33c0a812ddd576627ccc1a9', queries,  });
export default client;
  